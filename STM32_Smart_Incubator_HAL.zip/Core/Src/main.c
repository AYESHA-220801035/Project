#include "main.h"
#include "i2c.h"
#include "gpio.h"
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#define HTU21D_ADDR (0x40 << 1)
#define BH1750_ADDR (0x23 << 1)
#define LCD_ADDR (0x27 << 1)
#define TEMP_HIGH_TH 37.5f
#define HUM_LOW_TH 75.0f
void SystemClock_Config(void);
void LCD_SendCommand(uint8_t cmd){uint8_t u=cmd&0xF0,l=(cmd<<4)&0xF0,d[4]={u|0x0C,u|0x08,l|0x0C,l|0x08};HAL_I2C_Master_Transmit(&hi2c1,LCD_ADDR,d,4,100);}
void LCD_SendData(uint8_t data){uint8_t u=data&0xF0,l=(data<<4)&0xF0,d[4]={u|0x0D,u|0x09,l|0x0D,l|0x09};HAL_I2C_Master_Transmit(&hi2c1,LCD_ADDR,d,4,100);}
void LCD_Clear(void){LCD_SendCommand(0x01);HAL_Delay(2);}
void LCD_Init(void){HAL_Delay(50);LCD_SendCommand(0x33);HAL_Delay(5);LCD_SendCommand(0x32);HAL_Delay(1);LCD_SendCommand(0x28);HAL_Delay(1);LCD_SendCommand(0x0C);HAL_Delay(1);LCD_Clear();}
void LCD_SetCursor(uint8_t row,uint8_t col){LCD_SendCommand((row?0xC0:0x80)+col);}
void LCD_SendString(char *str){while(*str)LCD_SendData(*str++);}
HAL_StatusTypeDef HTU21D_Read(float *temp,float *hum){uint8_t cmd,buf[2];uint16_t raw;cmd=0xE3;if(HAL_I2C_Master_Transmit(&hi2c1,HTU21D_ADDR,&cmd,1,100)!=HAL_OK)return HAL_ERROR;HAL_Delay(50);if(HAL_I2C_Master_Receive(&hi2c1,HTU21D_ADDR,buf,2,100)!=HAL_OK)return HAL_ERROR;raw=(buf[0]<<8)|buf[1];raw&=0xFFFC;*temp=-46.85f+(175.72f*raw/65536.0f);cmd=0xE5;if(HAL_I2C_Master_Transmit(&hi2c1,HTU21D_ADDR,&cmd,1,100)!=HAL_OK)return HAL_ERROR;HAL_Delay(50);if(HAL_I2C_Master_Receive(&hi2c1,HTU21D_ADDR,buf,2,100)!=HAL_OK)return HAL_ERROR;raw=(buf[0]<<8)|buf[1];raw&=0xFFFC;*hum=-6.0f+(125.0f*raw/65536.0f);return HAL_OK;}
HAL_StatusTypeDef BH1750_Init(void){uint8_t c=0x01;if(HAL_I2C_Master_Transmit(&hi2c1,BH1750_ADDR,&c,1,100)!=HAL_OK)return HAL_ERROR;HAL_Delay(10);c=0x07;HAL_I2C_Master_Transmit(&hi2c1,BH1750_ADDR,&c,1,100);HAL_Delay(10);return HAL_OK;}
HAL_StatusTypeDef BH1750_ReadLux(float *lux){uint8_t c=0x10,b[2];if(HAL_I2C_Master_Transmit(&hi2c1,BH1750_ADDR,&c,1,100)!=HAL_OK)return HAL_ERROR;HAL_Delay(180);if(HAL_I2C_Master_Receive(&hi2c1,BH1750_ADDR,b,2,100)!=HAL_OK)return HAL_ERROR;*lux=((b[0]<<8)|b[1])/1.2f;return HAL_OK;}
void I2C_Scan(void){char s[17];for(uint16_t i=1;i<128;i++)if(HAL_I2C_IsDeviceReady(&hi2c1,i<<1,2,10)==HAL_OK){snprintf(s,sizeof(s),"Found 0x%02X",i);LCD_SetCursor(0,0);LCD_SendString(s);HAL_Delay(500);}}
int main(void){HAL_Init();SystemClock_Config();MX_GPIO_Init();MX_I2C1_Init();LCD_Init();LCD_SetCursor(0,0);LCD_SendString("INCUBATOR READY ");HAL_Delay(2000);I2C_Scan();BH1750_Init();float temp=0,hum=0,lux=0;char l1[17],l2[17];bool alarm=false,ack=false;while(1){HAL_StatusTypeDef hs=HTU21D_Read(&temp,&hum),bs=BH1750_ReadLux(&lux);if(hs==HAL_OK){alarm=(temp>TEMP_HIGH_TH||hum<HUM_LOW_TH);if(!alarm)ack=false;}else{alarm=false;ack=false;}HAL_GPIO_WritePin(GPIOA,GPIO_PIN_5,alarm?GPIO_PIN_SET:GPIO_PIN_RESET);HAL_GPIO_WritePin(GPIOA,GPIO_PIN_8,(alarm&&!ack)?GPIO_PIN_SET:GPIO_PIN_RESET);if(hs==HAL_OK)snprintf(l1,sizeof(l1),"T:%-4.1fC H:%-4.1f%%",temp,hum);else snprintf(l1,sizeof(l1),"T:ERR  H:ERR    ");if(bs==HAL_OK)snprintf(l2,sizeof(l2),"L:%-5.0flx %s",lux,alarm?"ALARM":"OK");else snprintf(l2,sizeof(l2),"L:ERR           ");LCD_SetCursor(0,0);LCD_SendString(l1);LCD_SetCursor(1,0);LCD_SendString(l2);for(int i=0;i<50;i++){if(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_13)==GPIO_PIN_RESET){HAL_Delay(50);if(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_13)==GPIO_PIN_RESET){if(alarm)ack=true;while(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_13)==GPIO_PIN_RESET)HAL_Delay(10);}}HAL_Delay(10);}}}
void SystemClock_Config(void){RCC_OscInitTypeDef o={0};RCC_ClkInitTypeDef c={0};__HAL_RCC_PWR_CLK_ENABLE();__HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);o.OscillatorType=RCC_OSCILLATORTYPE_HSI;o.HSIState=RCC_HSI_ON;o.HSICalibrationValue=RCC_HSICALIBRATION_DEFAULT;o.PLL.PLLState=RCC_PLL_ON;o.PLL.PLLSource=RCC_PLLSOURCE_HSI;o.PLL.PLLM=16;o.PLL.PLLN=336;o.PLL.PLLP=RCC_PLLP_DIV4;o.PLL.PLLQ=2;o.PLL.PLLR=2;if(HAL_RCC_OscConfig(&o)!=HAL_OK)Error_Handler();c.ClockType=RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK|RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;c.SYSCLKSource=RCC_SYSCLKSOURCE_PLLCLK;c.AHBCLKDivider=RCC_SYSCLK_DIV1;c.APB1CLKDivider=RCC_HCLK_DIV2;c.APB2CLKDivider=RCC_HCLK_DIV1;if(HAL_RCC_ClockConfig(&c,FLASH_LATENCY_2)!=HAL_OK)Error_Handler();}
void Error_Handler(void){__disable_irq();while(1){}}
