#include <sys/stat.h>
#include <stdlib.h>
#include <errno.h>
#include <stdio.h>
#include <signal.h>
#include <time.h>
#include <sys/time.h>
#include <sys/times.h>
extern int __io_putchar(int ch) __attribute__((weak));
extern int __io_getchar(void) __attribute__((weak));
char *__env[1]={0}; char **environ=__env;
void initialise_monitor_handles(void){}
int _getpid(void){return 1;} int _kill(int p,int s){(void)p;(void)s;errno=EINVAL;return -1;}
void _exit(int status){_kill(status,-1);while(1){}}
int _read(int f,char *p,int l){(void)f;for(int i=0;i<l;i++)p[i]=__io_getchar();return l;}
int _write(int f,char *p,int l){(void)f;for(int i=0;i<l;i++)__io_putchar(*p++);return l;}
int _close(int f){(void)f;return -1;} int _fstat(int f,struct stat*s){(void)f;s->st_mode=S_IFCHR;return 0;} int _isatty(int f){(void)f;return 1;}
int _lseek(int f,int p,int d){(void)f;(void)p;(void)d;return 0;} int _open(char*p,int f,...){(void)p;(void)f;return -1;}
int _wait(int*s){(void)s;errno=ECHILD;return -1;} int _unlink(char*n){(void)n;errno=ENOENT;return -1;} int _times(struct tms*b){(void)b;return -1;}
int _stat(char*f,struct stat*s){(void)f;s->st_mode=S_IFCHR;return 0;} int _link(char*o,char*n){(void)o;(void)n;errno=EMLINK;return -1;}
int _fork(void){errno=EAGAIN;return -1;} int _execve(char*n,char**a,char**e){(void)n;(void)a;(void)e;errno=ENOMEM;return -1;}