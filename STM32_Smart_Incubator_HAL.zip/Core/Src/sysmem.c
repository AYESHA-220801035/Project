#include <errno.h>
#include <stdint.h>
#include <stddef.h>
static uint8_t *__sbrk_heap_end = NULL;
void *_sbrk(ptrdiff_t incr){extern uint8_t _end;extern uint8_t _estack;extern uint32_t _Min_Stack_Size;const uint32_t stack_limit=(uint32_t)&_estack-(uint32_t)&_Min_Stack_Size;uint8_t *max_heap=(uint8_t*)stack_limit;uint8_t *prev;if(!__sbrk_heap_end)__sbrk_heap_end=&_end;if(incr<0 || __sbrk_heap_end+incr>max_heap){errno=ENOMEM;return(void*)-1;}prev=__sbrk_heap_end;__sbrk_heap_end+=incr;return prev;}